import org.junit.Test;

import static org.junit.Assert.*;

public class YoungTest {

    @Test
    public void main() {
        YoungModified young = new YoungModified();
assertEquals("YES", YoungModified.main(2,1,2,1,-1,-2,-1));

        assertEquals("NO", YoungModified.main(3,4,2,1,3,4,5,6,7,0));

        assertEquals("YES", YoungModified.main(3,4,2,1,-2,-1,-1,-2,-1,0));
    }
}